import os
import zipfile
import urllib.request

import xbmc
import xbmcgui
import xbmcvfs

BUILD_URL = "https://github.com/j-netzen/kodi-repo/releases/download/build/hubtop_build.zip"

dialog = xbmcgui.Dialog()


def download(url, dest):
    progress = xbmcgui.DialogProgress()
    progress.create("Hubtop Build Wizard", "Downloading build...")
    with urllib.request.urlopen(url) as resp, open(dest, "wb") as out:
        total = int(resp.headers.get("Content-Length", 0))
        done = 0
        while True:
            chunk = resp.read(1024 * 256)
            if not chunk:
                break
            out.write(chunk)
            done += len(chunk)
            if total:
                progress.update(int(done * 100 / total), "Downloading build...")
            if progress.iscanceled():
                progress.close()
                raise Exception("Download cancelled")
    progress.close()


def extract(zip_path, target):
    progress = xbmcgui.DialogProgress()
    progress.create("Hubtop Build Wizard", "Installing build...")
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
        for i, name in enumerate(names):
            zf.extract(name, target)
            progress.update(int(i * 100 / len(names)), "Installing build...")
    progress.close()


def main():
    if not dialog.yesno(
        "Hubtop Build Wizard",
        "This installs the Hubtop build and may overwrite your current add-ons and settings.\n\nContinue?",
    ):
        return

    tmp_zip = os.path.join(xbmcvfs.translatePath("special://temp/"), "hubtop_build.zip")
    home = xbmcvfs.translatePath("special://home/")

    try:
        download(BUILD_URL, tmp_zip)
        extract(tmp_zip, home)
    except Exception as e:
        dialog.ok("Hubtop Build Wizard", "Install failed:\n%s" % e)
        return
    finally:
        if os.path.exists(tmp_zip):
            os.remove(tmp_zip)

    dialog.ok(
        "Hubtop Build Wizard",
        "Build installed.\n\nKodi must now close. Reopen it to finish.",
    )
    os._exit(1)


main()
